# R1 GO/NO-GO gate report

All gates below use the frozen samples, covariates, age strata, and response
definitions in `R1_PREREGISTERED_QUESTIONS.md`. No age or radius cut was chosen
after inspecting a result.

| Gate | Status | Evidence and consequence |
|---|---|---|
| G1 raw $J_z$ | **CONDITIONAL** | The raw young-stratum slope is +0.0379 kpc$^{-1}$ (95% CI -0.0021--0.0778), whereas the ratio slope is -0.0145 kpc$^{-1}$ (CI -0.0545--0.0254). The global raw age×radius coefficient is +0.0753 (bootstrap slope curves in `action_gradient_vs_age.csv`). Thus age-dependent organisation is supported, but a significant young negative raw-$J_z$ trend is not. The manuscript must say that the ratio result is weak/normalisation-sensitive and must not claim decreasing young $J_z$. |
| G2 $J_R$ | **PASS** | $J_R$ has positive radial slopes in all frozen age strata (0.0455, 0.0423, 0.0405 kpc$^{-1}$ for young/intermediate/old) and a modest negative age×radius coefficient (-0.0124, 95% CI -0.0180-- -0.0067). It is a physical co-primary dimension, not an age proxy and not a one-to-one heating clock. |
| G3 warp | **CONDITIONAL** | The full-sample raw-$J_z$ age×radius coefficient is +0.0753, but it changes to -0.0516 for $R_g<9$ kpc and +0.0212 for $R_g<10$ kpc; the outer-disc leverage is material. The m=1 nuisance fit retains +0.0704. Exact warped actions were not computed. Outer-disc claims must be qualified. |
| G4 selection | **PASS** | Distance, RV-member, membership, inner-disc, and nuisance-adjusted samples all retain positive raw-$J_z$ age×radius coefficients (+0.0520 to +0.1016); amplitudes vary. Selection is a quantified limitation, not proven absent. |
| G5 potential | **PASS (tested family only)** | MWPotential2014 and +/-20% disk variants retain positive raw-$J_z$ and $J_R$ age×radius coefficients. The $J_z$ rank correlation exceeds 0.998; the more sensitive $J_R$ rank correlation remains >=0.729 while its fitted interaction sign is stable. The configured McMillan17 calculation is BLOCKED for a complete 1079-object downstream checkpoint, so no McMillan-specific claim is made. |
| G6 stellar control | **PASS (completed contrastive benchmark)** | The frozen 245,116-star Gaia DR3 quality-controlled sample uses the common OC pipeline. Raw $J_z$ slopes are negative in all four pre-defined $J_R$ quartiles, but the continuous $R_g\times J_R$ interaction is unresolved; the benchmark is therefore a completed contrast rather than an age-mapping result. See `audit/r1/stellar_control/STELLAR_CONTROL_GATE.md`. |

## Strongest defensible R1 claim

The HUNT24 open-cluster sample supports an age-dependent organisation of radial
and vertical actions in guiding-radius space. The fitted raw-$J_z$ slope has a
positive age interaction, while the weak young negative slope appears only in
the $J_z/|L_z|$ point estimate and does not exclude zero. $J_R$ supplies a
complementary, positive radial organisation with no well-constrained sign
transition. The direction survives the tested disk-mass, selection, and most
azimuthal sensitivity checks, but the amplitude is sensitive to outer-disc
leverage; no causal heating, flare, warp, or stellar-age interpretation is
established. The completed field-star benchmark shows a different ordering:
negative raw-$J_z$ gradients in every $J_R$ quartile with no resolved
$R_g\times J_R$ modulation. A complete McMillan17 downstream comparison remains
blocked.

This gate report is the stop-point requested before manuscript rewriting; the
revised manuscript below follows this qualified claim.
