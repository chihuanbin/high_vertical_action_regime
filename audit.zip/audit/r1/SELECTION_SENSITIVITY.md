# SELECTION_SENSITIVITY

Observable-proxy restrictions were pre-defined before fitting: d<=2 kpc, n_RV>=5, N>=100, Rg<10 kpc, plus a nuisance-adjusted model. These tests quantify sensitivity; they do not establish a complete selection function.

| sample              |    n |    beta_R |   beta_ageR |   beta_R_ci_low |   beta_R_ci_high |   distance_median_kpc |   abs_lat_median_deg |   abs_z_median_kpc | status   |
|:--------------------|-----:|----------:|------------:|----------------:|-----------------:|----------------------:|---------------------:|-------------------:|:---------|
| full                | 1079 | 0.0677077 |   0.07534   |       0.0458541 |        0.0895613 |               1.8991  |               2.32   |          0.0736065 | computed |
| distance_le_2kpc    |  574 | 0.0571241 |   0.0587334 |       0.0186873 |        0.0955609 |               1.30636 |               2.579  |          0.0621399 | computed |
| rv_members_ge_5     |  820 | 0.0821717 |   0.0688497 |       0.0538609 |        0.110483  |               1.72878 |               2.5555 |          0.0766123 | computed |
| members_ge_100      |  682 | 0.0559401 |   0.101617  |       0.0273914 |        0.0844887 |               1.99755 |               2.2845 |          0.0761888 | computed |
| inner_disc_Rg_lt_10 |  874 | 0.0964459 |   0.0212278 |       0.0679455 |        0.124946  |               1.65285 |               2.2375 |          0.0640409 | computed |
| nuisance_adjusted   | 1079 | 0.0517439 |   0.0519594 |       0.0299157 |        0.0735722 |             nan       |             nan      |        nan         | computed |
