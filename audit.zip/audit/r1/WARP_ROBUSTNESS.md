# WARP_ROBUSTNESS

Exact actions in a warped/non-axisymmetric potential were not claimed. W1 radial restrictions and W2 m=1 azimuthal nuisance terms were computed. W3 is BLOCKED because no published warp model was bundled with the local inputs; no z' or warped action was fabricated. W4 sector sample sizes are recorded as an exploratory extension in the machine-readable output.

| test                | setting         | response   |    beta_R |   beta_ageR |    n | status   |   sin_phi |   cos_phi |
|:--------------------|:----------------|:-----------|----------:|------------:|-----:|:---------|----------:|----------:|
| radial_restriction  | Rg<9            | log10_Jz   | 0.0914811 |  -0.0516159 |  704 | computed | nan       | nan       |
| radial_restriction  | Rg<10           | log10_Jz   | 0.0964459 |   0.0212278 |  874 | computed | nan       | nan       |
| radial_restriction  | Rg<11           | log10_Jz   | 0.0673294 |   0.0572212 |  995 | computed | nan       | nan       |
| radial_restriction  | full            | log10_Jz   | 0.0677077 |   0.07534   | 1079 | computed | nan       | nan       |
| azimuthal_harmonics | m=1 terms       | log10_Jz   | 0.24938   |   0.0704147 | 1079 | computed |   0.19692 |  -2.58951 |
| sector_consistency  | north_GLAT_ge_0 | log10_Jz   | 0.0371778 |   0.102432  |  495 | computed | nan       | nan       |
| sector_consistency  | south_GLAT_lt_0 | log10_Jz   | 0.0772385 |   0.0587692 |  584 | computed | nan       | nan       |
| sector_consistency  | phi_low_half    | log10_Jz   | 0.0708705 |   0.0878213 |  539 | computed | nan       | nan       |
| sector_consistency  | phi_high_half   | log10_Jz   | 0.0533006 |   0.0578558 |  540 | computed | nan       | nan       |
