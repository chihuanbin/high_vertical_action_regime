# Frozen sample selection and cutflow

## Pre-registration

The benchmark uses the Gaia DR3 source catalogue without chemistry, colour, CMD, or metallicity cuts. The frozen baseline is RV present; positive parallax; `parallax_over_error >= 10`; `ruwe < 1.4`; `radial_velocity_error <= 5 km s^-1`; `rv_nb_transits >= 5`; `d = 1/parallax < 2.5 kpc`; and, after the common Galactocentric transform, `|z| < 1.5 kpc`. The seeded FlatHUB random sample and all constants are in `DATA_ACQUISITION.md`.

## Counts

`RNG_SEED = 20260714`; the seeded input pool contains 246,027 rows, the
post-quality/action-valid pool contains 246,026 rows, and the final benchmark
contains 245,116 stars after the pre-registered `|z|` geometry cut.

| stage | N |
|---|---:|
| downloaded seeded Gaia pool | 246,027 |
| finite required observables | 246,027 |
| positive parallax | 246,027 |
| parallax S/N >= 10 | 246,027 |
| RUWE < 1.4 | 246,027 |
| RV error <= 5 km/s | 246,027 |
| RV transits >= 5 | 246,027 |
| d < 2.5 kpc | 246,027 |
| finite valid actions and derived quantities | 246,026 |
| |z| < 1.5 kpc | **245,116** |

The one failed action evaluation and 910 post-transform `|z|` exclusions are objective validity/geometry rules, not action-space outlier rejection. The exact machine-readable cutflow is `sample_cutflow.csv`; the final table is `data/processed/r1_gaia_dr3_stellar_control.parquet`.

## Selection-function limitation

The result is a quality-controlled Gaia DR3 6D benchmark, not a complete or volume-complete reconstruction of the Gaia selection function. The sensitivity table tests only observable proxies (distance, parallax S/N, RV precision, and vertical range).
