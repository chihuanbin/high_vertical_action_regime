# Local stellar-control data audit

**Timestamp:** 2026-09-14 (Asia/Shanghai)  
**Scope:** repository and its tracked/generated data products; raw HUNT24 inputs were read-only.

## Result

`LOCAL_SAMPLE = NOT_FOUND`.

I enumerated CSV, TSV, Parquet, FITS, HDF5 and Feather files under the repository and inspected their headers. The local products are HUNT24/open-cluster catalogues, action/orbit catalogues, matched OC diagnostics, or R1 results. None contains the required Gaia field-star identifier and six-dimensional observable set (`source_id`, `ra`, `dec`, `parallax`, `pmra`, `pmdec`, `radial_velocity`). The few files with `pmRA`/`pmDE` are cluster-level tables, not individual Gaia sources; they do not satisfy the control-sample definition.

No local Gaia RV catalogue, Gaia DR3 6D parquet/FITS product, or suitable prior field-star sample was found. The prior R1 blocker (`audit/r1/STELLAR_CONTROL.md`) is consistent with this audit.

## Acquisition decision

The benchmark is therefore acquired from a public Gaia DR3 service. The query, schema verification, seeded sampling, and download metadata are recorded in `analysis_r1/stellar_control/`, `audit/r1/stellar_control/DATA_ACQUISITION.md`, and the machine-readable sample summary. No raw HUNT24 or rev0/R1 numerical product was overwritten.

## Reproducibility note

The public FlatHUB Gaia DR3 interface exposes the same Gaia DR3 `gaia_source` fields and a server-side seeded random sample. The official Gaia DR3 schema documentation was checked independently; a TAP mirror pilot query returned all requested columns. The final acquisition uses the seeded FlatHUB API because the ESA endpoint was DNS-unreachable in this environment and its Heidelberg TAP mirror timed out for the unpartitioned quality query.
