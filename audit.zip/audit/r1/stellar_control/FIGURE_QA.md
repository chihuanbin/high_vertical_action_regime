# Stellar-control figure QA

The four requested PDFs were regenerated from the machine-readable outputs on
2026-09-14 using the Python/matplotlib backend. The plotting sources passed the
dependency-free source preflight with zero `FAIL` findings. PDF text audits
found a minimum glyph size of 5.6 pt in every figure (required minimum 5 pt),
with editable PDF/SVG text and 600-dpi TIFF exports present.

Panel-level visual checks:

| Figure | Panel claim | Uncertainty / density encoding | QA outcome |
|---|---|---|---|
| `fig_stellar_Rg_JR_colored_Jz` | `R_g`–`J_R` structure and median raw/normalised `J_z` | hexbin medians, minimum 30 stars per bin | pass; labels and colour bars clear |
| `fig_stellar_Jz_radial_slope_vs_JR` | continuous stellar radial slope versus `J_R` | bootstrap 95% bands | pass; raw and normalised curves distinguishable |
| `fig_stellar_normalization_audit` | fixed-quartile raw versus normalised slopes | bootstrap 95% error bars | pass; zero reference and units visible |
| `fig_OC_vs_stellar_action_ordering` | OC chronological versus stellar radial-action ordering | bootstrap bands for both axes | pass; axes explicitly state they are not interchangeable |

No points were removed for visual convenience; the objective action/geometry
cutflow is recorded in `sample_cutflow.csv`.
