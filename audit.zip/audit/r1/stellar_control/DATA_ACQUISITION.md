# Gaia DR3 control-sample acquisition

## Service and schema

The schema was verified on 2026-09-14 with a `TOP 1` query against the public Heidelberg Gaia DR3 TAP mirror (`https://gaia.ari.uni-heidelberg.de/tap/sync`) and against the Gaia DR3 data-model documentation. The requested fields all returned in the pilot response:

`source_id`, `ra`, `dec`, `parallax`, `parallax_error`, `pmra`, `pmra_error`, `pmdec`, `pmdec_error`, `radial_velocity`, `radial_velocity_error`, `ruwe`, `rv_nb_transits`, `duplicated_source`, `phot_g_mean_mag`, `l`, `b`, `random_index`, `parallax_over_error`.

The final download uses FlatHUB's Gaia DR3 catalogue API (`https://flathub.flatironinstitute.org/gaiadr3/catalog`), which documents the same DR3 source catalogue and exposes a deterministic `sample=<fraction>@<seed>` parameter plus `offset`/`limit` pagination. This avoids an arbitrary sky patch and does not claim a complete Gaia selection function.

## Frozen query definition

The server-side filters are:

```text
parallax in [0.4, 1000] mas
parallax_over_error in [10, 1000]
radial_velocity present
radial_velocity_error in [0, 5] km/s
ruwe in [0, 1.4]
rv_nb_transits in [5, 1000]
```

The local builder re-applies the exact predicates, requires finite proper motions and their errors, computes `d[kpc] = 1/parallax`, and applies `d < 2.5 kpc` and post-transformation `|z| < 1.5 kpc`. The local quality pass is retained in the sample-selection audit so server-side and local counts can be checked independently.

## Seed and pagination

`RNG_SEED = 20260714`; `sample fraction = 0.02`; page size = 5000 (FlatHUB rejects larger pages); pages are requested with offsets 0, 5000, … within fixed source-id partitions until each partition's API-reported total is reached. The API's `random_index` is retained in the parquet output. The deterministic server-side sample is not re-randomised after filtering; only duplicate source IDs and objectively invalid rows are removed.

## Provenance

The complete request construction and download logic are in `analysis_r1/stellar_control/download_gaia_dr3_control.py`. The exact ADQL-style selection text is in `analysis_r1/stellar_control/gaia_dr3_control.adql`. The raw JSON page cache is kept outside the repository during acquisition; the final processed parquet and its SHA-256 hash are recorded by the builder. Internet access was required and explicitly approved for the public Gaia service.

The acquisition manifest records the UTC timestamp, git commit, seeded sample
parameters, partition count, input-row count, and CSV SHA-256 digest. The action
metadata records the same commit/configuration provenance together with galpy,
NumPy, pandas, statsmodels, and pyarrow versions and the final parquet digest.
