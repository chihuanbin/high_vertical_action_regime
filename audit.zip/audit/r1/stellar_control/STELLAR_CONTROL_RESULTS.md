# Stellar-control results

## Analysis definition

The primary response is raw `log10(J_z/[kpc km s^-1])`. A parallel response is `log10(J_z/|L_z|)`. The continuous model is a Huber robust regression

```text
response ~ (R_g - 8.178) * (log10 J_R - median(log10 J_R))
           + |z| + d_helio.
```

The four `J_R` bins (0–25%, 25–50%, 50–75%, 75–100%) and 200 deterministic bootstrap resamples were frozen before examining the outcomes. Bootstrap intervals use the fitted Huber weights in weighted least squares; the point estimates remain Huber RLM estimates.

## Continuous interaction

| response | beta_R | beta_RJR | N |
|---|---:|---:|---:|
| raw `log10 J_z` | -0.02586 | +0.00016 (95% bootstrap -0.00187,+0.00220) | 245,116 |
| `log10(J_z/|L_z|)` | -0.07871 | -0.02011 (95% bootstrap -0.02216,-0.01807) | 245,116 |

The raw slope is negative and statistically precise, but its change with the dynamical ordering coordinate `J_R` is consistent with zero. The normalised response is more negative and has a non-zero negative interaction; this is not interpreted as a raw `J_z` result.

For the pre-defined selection variants, the table reports the robust-regression
95% confidence intervals for the fitted interaction coefficients; the baseline
quartile and continuous diagnostics additionally use 200 deterministic
Huber-weighted bootstrap resamples.

## Fixed `J_R` quartiles

Raw `log10 J_z` slopes (dex kpc^-1; bootstrap 95% intervals):

| bin | N | slope | 95% CI |
|---|---:|---:|---:|
| Q1 (0–25%) | 61,279 | -0.05144 | [-0.05445,-0.04860] |
| Q2 (25–50%) | 61,279 | -0.02355 | [-0.02657,-0.02123] |
| Q3 (50–75%) | 61,279 | -0.01507 | [-0.01720,-0.01310] |
| Q4 (75–100%) | 61,279 | -0.02852 | [-0.03026,-0.02703] |

Normalised slopes are respectively -0.10146, -0.07453, -0.06767, and -0.09385 dex kpc^-1; all intervals exclude zero. Their non-monotonic Q1–Q4 pattern is why the normalised interaction is reported as a sensitivity result, not as a one-dimensional heating sequence.

## OC comparison

The OC chronological ordering in the existing R1 output shows a positive young/intermediate/old raw-`J_z` slope of +0.0379/+0.1074/+0.0878 dex kpc^-1 (the exact machine-readable values remain in `output/r1/action_gradient_vs_age.csv`). The field-star benchmark instead has a negative raw slope, with no resolved `J_R` interaction. Thus it does **not** provide qualitative agreement with the OC raw-`J_z` age organisation. This is a benchmark disagreement, not an analysis failure; possible explanations include different spatial selection, OC survival/birth selection, and the non-equivalence of stellar `J_R` to age.
