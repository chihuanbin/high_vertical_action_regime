# Stellar-control gate report

**Date:** 2026-09-14  
**Seed:** 20260714  
**Input:** Gaia DR3 seeded quality pool; all action quantities use the R1 OC implementation.

## Status

| gate | status | basis |
|---|---|---|
| SC1 — data | **PASS** | 245,116 final stars after objective action/geometry validity cuts (>=50,000 threshold) |
| SC2 — dynamical trend | **NEUTRAL** | raw `beta_RJR = +0.00016`, bootstrap 95% [-0.00187,+0.00220]; raw quartile slopes are all negative but non-monotonic |
| SC3 — normalisation | **PASS** | raw and `J_z/|L_z|` interaction models and quartile slopes completed |
| SC4 — comparability | **PASS** | common-pipeline reproduction has max relative difference 1.48e-15 |
| selection sensitivity | **PASS** | raw slope remains negative in all pre-defined variants; the normalised interaction remains negative, while its amplitude varies modestly |

## Frozen interpretation

The benchmark does not support the stronger statement that increasing stellar `J_R` reproduces the OC age ordering in raw vertical action. It supports a more limited statement: the quality-controlled field-star sample has a negative raw `J_z`–`R_g` gradient, while the gradient's dependence on `J_R` is weak/neutral. The normalised quantity has a stronger negative gradient and a negative `R_g`×`J_R` interaction, demonstrating again that division by `|L_z|` changes the radial organisation.

`J_R` is used only as a dynamical ordering coordinate (kinematically colder/hotter); it is never treated as a direct stellar-age measurement. The `zmax_harmonic_kpc` column is a sensitivity diagnostic, not an exact integrated orbit maximum.

Integration status: this frozen gate was reviewed before manuscript integration. The completed benchmark is incorporated in `revision_r1/main_R1_clean.tex`, Figs.~5--6 and A.1, Table~4, the response letter, and `audit/r1/R1_CLAIM_AUDIT.md`.
