# R1 repository and numerical audit

Audit timestamp: 2026-09-14 (Asia/Shanghai). Git HEAD: `f3793be33b4046565f5003c09460dba1ab134e24`.

## A. Current scientific chain

The preserved rev0 chain is `hunt24/clusters.dat` -> fixed-width parser in
`src/oc_vertical_actions/catalogue.py` -> 1079 type `o` quality-selected OCs
(`results/tables/master_sample.csv`) -> Galactocentric phase-space conversion
and cached 300-draw actions (`results/cache/action_draws_*.parquet`) -> nominal
orbit catalogue -> robust age/radius models -> secondary flare, null, matching,
and exploratory GMM/VEAR products -> `manuscript_aa/main.tex`. Raw HUNT24 files,
rev0 manuscript sources/PDFs, and all existing `results/` products are retained.
The R1 products are written only under `analysis_r1/`, `output/r1/`,
`figures/r1/`, `audit/r1/`, and `revision_r1/`.

Relevant inputs/products found: `clusters.dat`, `members.dat`, `crossma.dat`;
`scripts/run_aa_pipeline.py`; `src/oc_vertical_actions/{catalogue,audit,
uncertainty,dynamics,action_pipeline,orbits,models,publication}.py`;
cached MWPotential2014, +/-20% disk caches, and a small McMillan17 smoke cache;
continuous-model, quantile, flare/null, matching, GMM, bootstrap, and figure
products under `results/`.

## B--H. Actions, centres, and orbit quantities

* **Action definitions.** `compute_actions` calls `galpy.actionAngleStaeckel`
  for $(J_R,L_z,J_z)$ and multiplies galpy's dimensionless actions by
  $R_0V_0$ to obtain kpc km s$^{-1}$. $L_z$ keeps galpy's sign; ratios use
  $|L_z|$. Non-finite or negative $J_R/J_z$ draws are invalid.
* **Cluster centre of mass.** Actions use one HUNT24 catalogue phase-space
  vector per cluster (`RAdeg`, `DEdeg`, `dist50`, `pmRA`, `pmDE`, `RV`). These
  are HUNT24 aggregate/mean cluster quantities, not actions averaged over
  member-star actions. `members.dat` is not used to recompute the action
  centre or a full covariance matrix in the rev0 action chain.
* **Solar/Galactic parameters.** Fiducial $R_0=8.178$ kpc, $z_\odot=20.8$
  pc, $V_c(R_0)=236.9$ km s$^{-1}$, and solar peculiar velocity
  $(U,V,W)=(11.1,12.24,7.25)$ km s$^{-1}$, passed to galpy's right-handed
  Galactocentric convention. Fiducial potential is galpy `MWPotential2014`;
  +/-20% disk variants are scaled copies. `McMillan17` is configured but has
  no complete production checkpoint.
* **Staeckel implementation.** `estimateDeltaStaeckel(pot,R,z,no_median=True)`
  is evaluated per draw; non-positive/non-finite values fall back to
  `legacy_delta=0.45`. The finder is constructed with `c=True` for
  MWPotential2014 (otherwise `c=False`) and called with the estimated delta.
  galpy version is 1.11.1.
* **Guiding radius.** The exact code is `galpy.potential.rl(pot, abs(lz))`
  multiplied by the potential's $R_0$. Thus $R_g$ is the radius of the
  circular orbit with the same absolute angular momentum, not a mean,
  $(R_{\rm peri}+R_{\rm apo})/2$, or `rguiding` estimate.
* **Orbit integration.** Nominal orbits use DOP853 (`dop853_c` for
  MWPotential2014), 20 vertical periods clipped to 2--10 Gyr, at least 200
  samples per vertical period and at least 1001 time points. `zmax` is the
  maximum absolute integrated $z$; eccentricity is
  $(R_{\rm apo}-R_{\rm peri})/(R_{\rm apo}+R_{\rm peri})$.
* **Uncertainty propagation.** 300 independent catalogue-error draws use
  split-normal distance/age intervals and normal proper-motion/RV errors with
  seed 20260714. HUNT24 does not publish a complete cluster-level covariance;
  therefore these are not full covariance draws. Existing member-bootstrap
  covariance products are ancillary and were not silently substituted.
* **Precision selection.** The 1079-object parent sample is reduced to 1078
  when `invalid_draw_fraction <= 0.1` and the 16--84% relative $J_z$ interval
  is <=1.0. The sole exclusion is ID 4216, **HXHWL_37**: zero invalid draws,
  but relative $J_z$ interval **1.00967648**, just above the frozen threshold.

## I--K. Provenance

SHA-256: `clusters.dat` `22c60d469423a5dd9df817bdbc99bae09483b7c8a8e98661fa3011c728459410`;
`members.dat` `05c060807956226aaed713720e772eb2c4259a990ef8d4bc1cd9fb66ead1a599`;
`crossma.dat` `d74111971392d55c4f9bd6352629dfa7f4b7127ff2d62c274f4827fac1d5d299`;
`analysis.yaml` `9e646979b84599a29c0cb01d58032523b19742de8872fea0165373a873205a0f`.
The R1 run metadata records the input-table hash, seed, package versions,
timestamp, and git commit. Installed versions include numpy 2.1.3, pandas 2.2.3,
scipy 1.15.3, matplotlib 3.10.0, astropy 7.0.0, galpy 1.11.1,
scikit-learn 1.8.0, statsmodels 0.14.4, and patsy 1.0.1.

The HUNT24 source table contains 7167 rows and the verified crossmatch contains
29956 rows. No raw input was overwritten.
