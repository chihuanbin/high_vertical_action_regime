# STELLAR_CONTROL

**Status: COMPLETED CONTRASTIVE BENCHMARK.** A quality-controlled Gaia DR3
six-dimensional sample of 245,116 stars is preserved in
`data/processed/r1_gaia_dr3_stellar_control.parquet`. It was transformed and
analysed with the same solar parameters, Galactic potential, Staeckel action
implementation, and guiding-radius definition as the OC sample. The common
pipeline test, including exact $R_g$, passed.

The raw-$J_z$ radial coefficient is $-0.02586$ and the continuous
$R_g\times J_R$ interaction is $+0.00016$ (unresolved). Raw slopes are
negative in all four pre-defined $J_R$ quartiles. The normalized response is
more negative and more $J_R$-dependent. Thus the benchmark does not reproduce
the OC chronological ordering; $J_R$ remains a dynamical ordering coordinate,
not a direct stellar-age measurement.

The benchmark is not a complete Gaia selection-function reconstruction.
Frozen acquisition, quality cuts, cutflow, sensitivity tests, machine-readable
outputs, and figures are documented under `audit/r1/stellar_control/`,
`output/r1/stellar_control/`, and `figures/r1/stellar_control/`.
