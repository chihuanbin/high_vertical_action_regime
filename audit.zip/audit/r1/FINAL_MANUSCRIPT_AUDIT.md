# FINAL_MANUSCRIPT_AUDIT

Audit date: 2026-09-15. This is the final R1 consolidation audit; no model,
sample cut, age bin, quartile definition, or post-hoc significance tuning was
performed.

## Package and build

| Check | Status | Evidence |
|---|---|---|
| Clean manuscript source | PASS | `revision_r1/main_R1_clean.tex` contains no `\\DIF` revision macros. |
| Clean manuscript compile | PASS | Two stable `latexmk -pdf -interaction=nonstopmode -halt-on-error` passes; seven-page `main_R1_clean.pdf`; no fatal errors, undefined controls, missing references, missing figures, or overfull boxes. Underfull boxes are non-fatal. |
| Referee response compile | PASS | Two stable passes; five-page `response_to_referee_R1.pdf`; no fatal errors, undefined controls, missing references, missing figures, or overfull boxes. |
| Marked companion | PASS | Eight-page `main_R1_marked.pdf` generated with `latexdiff`; revisions are visibly marked and no figure/table is clipped. The optional diff source emits two markup-only overfull-box warnings; the clean production source does not. |
| Bibliography and A&A format | PASS | A&A class/style, affiliations, title, author and correspondence line, units, and citation formatting are present. All 24 cited keys resolve; five Chi et al. Gaia OC-census/membership references are used as contextual citations only, and metadata corrections are documented in `audit/r1/REFERENCE_AUDIT.md`. The supplied class/bibliography emits non-fatal repeated-citation notices. |
| Overleaf upload archive | PASS | `archive/overleaf_r1_upload/main_R1_clean_overleaf_R1_2026-09-15.zip` is source-only, contains the clean main file at its root plus all ten referenced figures and required A&A files, and compiles both from the staging directory and from a fresh extraction with an empty auxiliary state to seven pages without fatal, undefined-citation, or missing-figure diagnostics. |

## Cross-reference audit

- Figures 1--9 and Fig. A.1 are each introduced in running text before or at
  their caption. Figures 5--6 contain the OC--stellar comparison with separate
  chronological-age and dynamical-$J_R$ axes/panels, and Fig. A.1 is cited
  from the stellar normalization discussion.
- Tables 1--4 are each explicitly referenced: sample counts, potential
  configuration, frozen OC slope anchor, and stellar quartile slopes.
- Appendix A is cited from the action-projection and VEAR/GMM discussion;
  Appendix B is cited for machine-readable provenance and secondary products.
- `audit/r1/FINAL_FIGURE_AUDIT.md` and `audit/r1/FINAL_NUMERICAL_AUDIT.md`
  provide the figure-by-figure and value-by-value evidence trails.

## Scientific hierarchy and gates

1. OCs show positive $J_R$ radial organisation in all three frozen age
   strata; this is the primary action-space result.
2. Raw $J_z$ point estimates are non-negative in all strata, but the young
   interval crosses zero; only intermediate and old behaviour is clearly
   resolved.
3. The selected 245116-star Gaia DR3 benchmark has a negative raw-$J_z$
   radial gradient, but its four fixed-$J_R$ slopes are not monotonically
   ordered and its continuous interaction is unresolved (+0.00016).
4. OC age is chronological ordering, whereas stellar $J_R$ is dynamical
   ordering; the two are not interchangeable.
5. Dividing by $|L_z|$ materially changes radial structure and is retained as
   a normalization-sensitivity diagnostic, not as a replacement for raw
   actions.

The final gate statuses are: raw $J_z$ CONDITIONAL; $J_R$ PASS; potential PASS
within the tested family (McMillan17 downstream comparison BLOCKED); warp
CONDITIONAL; predefined selection tests PASS with qualified amplitudes; and
stellar-control benchmark PASS as a contrastive result with $J_R$ ordering
NEUTRAL.

## Language, terminology, and interpretation

- The clean manuscript uses the selected/quality-controlled Gaia DR3 stellar
  benchmark wording and does not generalize it to all Galactic field stars.
- No young negative raw-$J_z$ claim, sign-reversal claim, monotonic stellar
  quartile claim, or causal heating/survival/birth-condition claim remains.
- The discussion keeps the observation -> prediction -> consistency ->
  limitation structure for heating, migration, flaring, resonances, warp, and
  survival selection. It states explicitly that a weaker vertical restoring
  force can increase vertical amplitude without requiring a corresponding
  increase in vertical action.
- Warp language is conditional: tested restrictions preserve broad trends, but
  axisymmetric actions remain approximate in the outer warped disc. Selection
  language is limited to the predefined observability tests.
- BIC, ICL, GMM, ARI, VI, KDE, and VEAR are defined at first use in the
  relevant methods/appendix context. VEAR/GMM is appendix-only exploratory
  localisation and does not define a separate physical population or enter
  the primary slopes; the abstract and primary narrative use neutral wording.

## Residual risks for the referee

- The stellar benchmark is selected and quality-controlled, not a complete or
  volume-complete census; its contrastive scope is explicit.
- The warp gate remains conditional and the exact warped-action calculation is
  unavailable; this is a stated limitation, not a hidden assumption.
- Confirmatory CSV rows retain the frozen parent-catalogue count $n=1079$,
  while 1078 OCs pass the independent precision flag; the distinction is
  documented in the numerical audit and manuscript.
- The supplied A&A bibliography/class emits non-fatal repeated-citation
  notices despite resolved citations; this does not produce undefined
  references or alter the rendered output.
- The marked companion retains two diff-only overfull-box warnings from
  `latexdiff` markup; the clean manuscript and Overleaf upload source have no
  overfull boxes.

## Final disposition

The clean manuscript, marked companion, referee response, cover letter,
reference audit, Overleaf upload archive, and the final R1 audit files are
internally consistent and ready for A&A R1 resubmission, subject to the
conditional scientific claims listed above.
