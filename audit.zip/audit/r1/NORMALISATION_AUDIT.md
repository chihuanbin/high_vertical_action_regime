# NORMALISATION_AUDIT

Frozen comparison of identical 1079-object samples and covariates.

| response | young slope (<8) | intermediate (8--9) | old (>=9) |
|---|---:|---:|---:|
| log10_Jz | 0.037878 | 0.10736 | 0.087801 |
| log10_Jz_over_abs_Lz | -0.014541 | 0.061685 | 0.047802 |
| log10_JR | 0.045461 | 0.042271 | 0.04048 |

Interpretation is determined by the pre-registered cases A--D. The raw Jz and JR slopes are reported separately; a ratio slope is not interpreted as a raw-action slope.
