# R1 reference enrichment and verification audit

Audit date: 2026-09-15. The production bibliography source is
`manuscript_aa/references.bib`; `analysis_r1/build_r1_manuscript.py` copies it
to `revision_r1/references.bib` when generating the clean source. No numerical
result, sample definition, age boundary, or action-ordering rule was changed.

## Verification protocol

- Parsed all citation keys in `revision_r1/main_R1_clean.tex` and confirmed that
  every key resolves through the A&A BibTeX run.
- Checked title, author list, publication year, journal, volume, article/page
  identifier, and DOI against publisher pages or primary catalogue records for
  the newly cited and corrected entries below.
- Kept catalogue and membership papers in the Introduction as context for
  footprint/method dependence only; they are not used to support the frozen
  action gradients or any causal interpretation.

## New Chi et al. citations

| Key | Verified bibliographic record | Use in manuscript | Primary verification |
|---|---|---|---|
| `Chi2023HighLat` | Chi, H., Wang, F., Wang, W., Deng, H., & Li, Z. 2023, *ApJS*, 266, 36, doi:10.3847/1538-4365/accb50 | Gaia DR3 high-latitude OC search; motivates explicit footprint sensitivity | [SciX/ADS abstract](https://scixplorer.org/abs/2023ApJS..266...36C/abstract) |
| `Chi2023LISC` | Chi, H., Wang, F., & Li, Z. 2023, *RAA*, 23, 065008, doi:10.1088/1674-4527/accbad | Gaia EDR3 census expansion and incompleteness context | [RAA article](https://www.raa-journal.org/issues/all/2023/v23n6/202306/t20230609_169077.html) |
| `Chi2023Candidates` | Chi, H., Wei, S., Wang, F., & Li, Z. 2023, *ApJS*, 265, 20, doi:10.3847/1538-4365/acb2cc | Hybrid pyUPMASK/random-forest membership-method context | [CDS/VizieR catalogue record](https://cdsarc.cds.unistra.fr/viz-bin/ReadMe/J/ApJS/265/20?format=html&tex=true) |
| `Chi2024MvC` | Chi, H., Lai, Z., Wang, F., Li, Z., & Mei, Y. 2024, *RAA*, 24, 115021, doi:10.1088/1674-4527/ad8055 | Gaia DR3 multi-view membership and candidate-selection context | [RAA article](https://www.raa-journal.org/issues/all/2024/v24n11/202411/t20241127_251585.html) |
| `Chi2025Distant` | Chi, H., Kong, L., Chen, Z., Wang, F., Deng, H., & Mei, Y. 2025, *PASJ*, 77, 1050--1064, doi:10.1093/pasj/psaf082 | Distant (>5 kpc) Gaia DR3 search; motivates distance/selection qualification | [Oxford Academic article](https://academic.oup.com/pasj/article/77/5/1050/8236289) |

These five papers are cited together once in Sect. 1 in the sentence about
Gaia EDR3/DR3 searches, footprint, and membership methodology. The wording does
not claim that the selected R1 benchmark is complete or representative of all
Galactic stars.

## Corrected or completed existing entries

| Key | Correction | Verification |
|---|---|---|
| `Trick2019` | Corrected title to “The Galactic disc in action space as seen by Gaia DR2” and pages to 3291--3306 | [Oxford Academic](https://academic.oup.com/mnras/article/484/3/3291/5298491) |
| `Trick2022` | Corrected pages to 844--865 | [Oxford Academic](https://academic.oup.com/mnras/article/509/1/844/6383004) |
| `Kawata2021` | Corrected full author list and pages to 728--736 | [Oxford Academic](https://academic.oup.com/mnras/article/508/1/728/6371128) |
| `Smock2026` | Corrected full author list and DOI to 10.3847/1538-4357/ae7367 | [DOI record](https://doi.org/10.3847/1538-4357/ae7367) |
| `HuntVasiliev2025` | Corrected key/year to 2025 and first author initials to J.~A.~S.; DOI retained | [DOI record](https://doi.org/10.1016/j.newar.2024.101721) |
| `Hunt2024` | Added DOI 10.1051/0004-6361/202348662 | [CDS/VizieR record](https://cdsarc.cds.unistra.fr/viz-bin/cat/J/A%2BA/686/A42) |
| `Katz2023` | Added DOI 10.1051/0004-6361/202244220 | [A&A article](https://www.aanda.org/articles/aa/pdf/2023/06/aa44220-22.pdf) |

The remaining cited entries (`Frankel2020`, `Sellwood2019`, `Trick2021`,
`GaiaDR3Summary`, `Bovy2015`, `Binney2012`, `SandersBinney2016`,
`Wielen1977`, `AumerBinney2009`, `PortegiesZwart2010`, `Schwarz1978`, and
`KassRaftery1995`) retain their existing records; their use is limited to the
claims described by the corresponding sentences (migration, action estimation,
heating, cluster survival, or model-selection terminology).

## Build result

After regeneration, the clean manuscript bibliography contains 24 cited keys;
the A&A BibTeX run resolves all of them. The only residual log notices are the
known non-fatal repeated-citation notices emitted by the supplied A&A class;
there are no undefined citations, missing bibliography entries, or missing
DOI-related compile errors.
