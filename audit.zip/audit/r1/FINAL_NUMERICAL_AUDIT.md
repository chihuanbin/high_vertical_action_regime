# FINAL_NUMERICAL_AUDIT

Audit date: 2026-09-15. This is a single-source-of-truth check of the frozen R1 values. No analysis was rerun or retuned. The machine-readable sources are `output/r1/action_gradient_vs_age.csv`, `output/r1/jr_models.csv`, `output/r1/stellar_control/stellar_continuous_interaction.csv`, `output/r1/stellar_control/stellar_JR_quantile_Jz_slopes.csv`, `output/r1/stellar_control/stellar_normalization_audit.csv`, and `revision_r1/numeric_macros.tex`. Unless otherwise noted, displayed slope and coefficient values use exactly five decimal places; slope units are dex kpc^-1.

## Counts and precision gate

| Quantity | Frozen value | Machine-readable source/key | Manuscript locations | Display check |
|---|---:|---|---|---|
| Quality-selected OCs | 1079 | `results/tables/master_sample.csv`, row count; `output/r1/primary_results.csv`, row count | `main_R1_clean.tex:24,30`; abstract | integer, consistent |
| Action-precision OCs | 1078 | `results/tables/analysis_catalogue.csv`, `action_precision_sample=True`, unique ID count | `main_R1_clean.tex:30--34,64`; abstract | integer, consistent |
| Excluded object | HXHWL_37 | `results/tables/analysis_catalogue.csv`, `ID=4216`, name field | `main_R1_clean.tex:32,64`; response `:86` | exact spelling/ID |
| Excluded ID | 4216 | same row/key | `main_R1_clean.tex:32,64`; response `:86` | integer, consistent |
| Relative J_z interval | 1.00968 | same row, `Jz_kpc_kms_relative_interval`; macro `ROneExcludedRel` | `main_R1_clean.tex:33,64`; response `:86,132` | five decimals, consistent |

The confirmatory CSV rows have `n=1079`, matching the frozen parent catalogue used to generate the stored slopes; the separate precision flag remains 1078 and is not presented as a second sample count.

## OC slopes

| Response/stratum | Estimate and 95% CI | Source row/key | Manuscript locations |
|---|---|---|---|
| raw J_z, young | +0.03788 [-0.00207,+0.07783] | `action_gradient_vs_age.csv`, `row_type=age_stratum,response=log10_Jz,age_stratum=young`; macros `ROneRawJzYoung*` | `main_R1_clean.tex:87,102`; abstract qualitative only |
| raw J_z, intermediate | +0.10736 [+0.08283,+0.13190] | same, `age_stratum=intermediate`; macros `ROneRawJzIntermediate*` | `main_R1_clean.tex:87,103`; conclusions qualitative |
| raw J_z, old | +0.08780 [+0.04902,+0.12659] | same, `age_stratum=old`; macros `ROneRawJzOld*` | `main_R1_clean.tex:87,104`; conclusions qualitative |
| J_z/|L_z|, young | -0.01454 [-0.05453,+0.02545] | `action_gradient_vs_age.csv`, `response=log10_Jz_over_abs_Lz,age_stratum=young`; macros `ROneRatioYoung*` | `main_R1_clean.tex:91,102` |
| J_z/|L_z|, intermediate | +0.06168 [+0.03700,+0.08637] | same, `age_stratum=intermediate`; macros `ROneRatioIntermediate*` | `main_R1_clean.tex:103` |
| J_z/|L_z|, old | +0.04780 [+0.00902,+0.08659] | same, `age_stratum=old`; macros `ROneRatioOld*` | `main_R1_clean.tex:104` |
| J_R, young | +0.04546 [+0.03199,+0.05893] | `action_gradient_vs_age.csv`, `response=log10_JR,age_stratum=young`; macros `ROneJrYoung*` | `main_R1_clean.tex:83,102` |
| J_R, intermediate | +0.04227 [+0.03806,+0.04649] | same, `age_stratum=intermediate`; macros `ROneJrIntermediate*` | `main_R1_clean.tex:103` |
| J_R, old | +0.04048 [+0.02904,+0.05192] | same, `age_stratum=old`; macros `ROneJrOld*` | `main_R1_clean.tex:104` |

Raw-$J_z$ model summaries are `beta_R=0.06771`, `beta_ageR=0.07534`, crossover 7.10130; normalized summaries are `beta_R=0.01922`, `beta_ageR=0.08097`, crossover 7.76257; $J_R$ has `beta_R=0.04628`, `beta_ageR=-0.01237`, and no well-constrained transition. These are sourced from `action_gradient_vs_age.csv`, `row_type=model_summary`, and are displayed at `main_R1_clean.tex:90,93` or as qualitative conclusions.

## Stellar benchmark

| Quantity | Frozen value | Machine-readable source/key | Manuscript locations | Display check |
|---|---:|---|---|---|
| Final stars | 245116 | `stellar_sample_summary.csv`, `quantity=final_benchmark_rows` | abstract; `main_R1_clean.tex:40,115`; response `:58` | integer, consistent |
| Raw beta_R | -0.02586 | `stellar_normalization_audit.csv`, `response=log10_Jz,beta_R` | `main_R1_clean.tex:111,113`; response `:58` | five decimals |
| Raw beta_R,JR | +0.00016 | same row, `beta_RJR` | `main_R1_clean.tex:111`; response `:58` | five decimals |
| Raw beta_R 95% CI | [-0.02730,-0.02442] | same row, `beta_R_ci_low/high` | `main_R1_clean.tex:111`; response `:58` | five decimals |
| Normalized beta_R | -0.07871 | same table, `response=log10_Jz_over_abs_Lz,beta_R` | `main_R1_clean.tex:91,113`; response `:62` | five decimals |
| Normalized beta_R,JR | -0.02011 | same row, `beta_RJR` | `main_R1_clean.tex:113`; response `:62` | five decimals |
| Raw Q1 | -0.05144 [-0.05445,-0.04860] | `stellar_JR_quantile_Jz_slopes.csv`, `response=log10_Jz,JR_quantile=Q1_0_25` | `main_R1_clean.tex:111,125`; response `:58` | five decimals |
| Raw Q2 | -0.02355 [-0.02657,-0.02123] | same, `JR_quantile=Q2_25_50` | `main_R1_clean.tex:111,126`; response `:58` | five decimals |
| Raw Q3 | -0.01507 [-0.01719,-0.01310] | same, `JR_quantile=Q3_50_75` | `main_R1_clean.tex:111,127`; response `:58` | five decimals |
| Raw Q4 | -0.02852 [-0.03026,-0.02703] | same, `JR_quantile=Q4_75_100` | `main_R1_clean.tex:111,128`; response `:58` | five decimals |

All four quartile estimates are negative and all four intervals exclude zero. Their order is Q1, Q2, Q3, Q4 = -0.05144, -0.02355, -0.01507, -0.02852 and is not monotonic. The normalized stellar coefficients are used only as a normalization-sensitivity diagnostic.

## Reconciliation result

All required frozen values (1079, 1078, HXHWL_37, ID 4216, 1.00968, the three OC raw-$J_z$ slopes, the three $J_R$ slopes, 245116, -0.02586, +0.00016, four stellar quartiles, -0.07871, and -0.02011) occur with one displayed rounding convention in the clean source and response. No conflicting value was found. The only non-content build warnings are duplicate natbib-key warnings emitted by the supplied A&A bibliography/class combination; no citation is undefined.
