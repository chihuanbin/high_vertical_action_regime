# R1 pre-registered questions and frozen model

These questions and domains were frozen before reading the new R1 outputs.

1. Does raw $J_z$ show an age-dependent radial gradient?
2. Is the young-cluster result present in raw $J_z$, or induced/enhanced by
   $J_z/|L_z|$?
3. Does $J_R$ have its own age-dependent radial organisation?
4. Is a sign transition in the radial-action slope supported?
5. Do potential, precision, outer-disc/warp, observable-selection, and
   distance/RV restrictions change the qualitative conclusions?
6. Do Gaia field stars show analogous $R_g$--$J_R$--$J_z$ organisation?

For $A\in\{J_z,J_R\}$ the confirmatory model is

\[
\log_{10}A_i=\beta_0+\beta_{age}(\log_{10}\tau_i-8)
 +\beta_R(R_{g,i}-R_0)+\beta_{ageR}(\log_{10}\tau_i-8)(R_{g,i}-R_0)
 +\beta_e(e_i-e_0)+\epsilon_i,
\]

fit with Huber-T robust regression. $R_0$ is the fiducial-sample median
8.347486 kpc and $e_0$ is the fiducial-sample median eccentricity; the
implementation uses the centred column $e-e_0$. The supported age domain is the
observed 6.46237--9.72590 in log10(yr) range; slope curves are evaluated only
inside it. The three frozen responses are `log10_Jz`,
`log10_Jz_over_abs_Lz`, and `log10_JR`; secondary diagnostics are $z_{max}$,
$z_{max}/R_g$, and $\eta_z=J_z/(J_R+J_z)$. Non-positive actions are excluded
from logarithms, with no arbitrary offset.

The pre-defined age strata for the normalisation audit are young (<8),
intermediate (8--9), and old (>=9) in log10(yr). Warp tests are $R_g<9$, 10,
and 11 kpc plus fixed m=1 sine/cosine terms. Selection tests are d<=2 kpc,
n_RV>=5, N>=100, $R_g<10$ kpc, and a nuisance-adjusted model. Bootstrap seed
is 20260714; the same samples and covariates are used for all three responses.
