# FINAL_LANGUAGE_REDTEAM

Audit date: 2026-09-15. Search scope: all `*.tex`, `*.md`, and `*.txt` files
in the repository. The production source is `revision_r1/main_R1_clean.tex`;
historical drafts and audit evidence are not submitted as the clean manuscript.

## Forbidden-phrase disposition

| Search item | Occurrences and action | Final rationale |
|---|---|---|
| `sign reversal` | `audit/r1/R1_CLAIM_AUDIT.md` and historical gate material: **KEEP** as explicit NOT-SUPPORTED audit labels. No occurrence in clean manuscript or response prose. | The audit must document rejection of the rev0 interpretation. |
| `negative young` / `young negative` | `audit/r1/R1_GATE_REPORT.md` and claim-audit labels: **KEEP** as historical/evidentiary labels. Clean manuscript says the young raw slope is compatible with zero. | No unsupported young negative result remains in production prose. |
| `generic field-star` | No production occurrence; earlier wording in historical material was **REWRITE** to “selected/quality-controlled Gaia DR3 stellar benchmark.” | The benchmark is not generalized to all field stars. |
| `J_R as an age proxy` | Referee quotation in the response and historical review notes: **KEEP** as quoted context; response immediately states that $J_R$ is only a dynamical ordering coordinate. | Quoted referee language is not an author claim. |
| `proves` | Historical `aa.md` and `hybrid.md`: **KEEP** as archived material, not production source. Clean manuscript uses “supports,” “is compatible with,” or “does not establish.” | Causal proof language is absent from the revised manuscript. |
| `demonstrates heating` | No occurrence in production source. Heating discussion was **REWRITE** to “compatible with radial excitation or birth orbital structure, but is not itself proof of heating.” | Action gradients are not assigned a unique mechanism. |
| `selection effects are negligible` | No occurrence. Selection discussion was **REWRITE** to predefined observability tests with qualified amplitudes. | The selection gate is not presented as elimination of bias. |
| `warp has no effect` | No occurrence. Warp discussion was **REWRITE** to a conditional gate and approximate axisymmetric actions in the outer warped disc. | Warp sensitivity remains visible. |
| `field stars reproduce` | No occurrence in production prose; benchmark text states that stellar $J_R$ ordering does not reproduce OC chronology. | The comparison is contrastive and selected-sample limited. |
| `distinct population` | Historical `hybrid.md`/`v3.txt` occurrences: **KEEP** as archived evidence; the clean source was **REWRITE**d to “does not define a separate physical population, mechanism, or causal driver.” | VEAR/GMM remains descriptive and appendix-only. |
| `flare measurement` | **REWRITE** in the clean source and figure audit to “does not measure geometric flaring” / “not a measurement of geometric flaring.” | Geometric amplitude is not conflated with vertical action. |

## Positive wording checks

- Raw-$J_z$ wording distinguishes point estimates from uncertainty: young
  `+0.03788 [-0.00207,+0.07783]` is consistent with zero; intermediate and old
  intervals exclude zero.
- Stellar quartile wording states all four slopes are negative but not
  monotonically or systematically ordered by $J_R$; the continuous interaction
  is reported as `+0.00016` without a resolved modulation claim.
- The field-star sample is consistently called a selected or quality-controlled
  Gaia DR3 benchmark, never a generic or complete Galactic population.
- VEAR/GMM is confined to Appendix A in the clean manuscript; the abstract,
  Introduction, Discussion, and Conclusions use the neutral phrase
  “exploratory mixture analysis” when referring to that diagnostic.
- The cover letter uses “unresolved-young-slope/sign-transition” wording and
  does not restate the rejected rev0 interpretation as a result.
- Normalization wording uses “normalization-dependent radial structure” and
  “normalization sensitivity”; no “artifact,” “spurious,” or “fake trend” claim
  is made.
- Mechanisms are framed as observation -> prediction -> consistency ->
  limitation, with no unique birth, heating, migration, survival, flare, or
  perturbing-mechanism attribution.

## Result

The clean production manuscript and referee response pass the language red-team.
The remaining matches are intentionally retained only in historical drafts,
referee quotations, or required audit labels and are excluded from the clean
submission source.
