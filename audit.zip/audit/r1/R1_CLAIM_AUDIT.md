# R1_CLAIM_AUDIT

Audit date: 2026-09-15. Statuses below are frozen-gate decisions, not new statistical tests. The OC age coordinate is chronological; stellar $J_R$ is dynamical and is never used as a stellar-age estimator.

| CLAIM | STATUS | Evidence and permitted manuscript wording |
|---|---|---|
| Young OCs have a negative raw-$J_z$ gradient. | **NOT SUPPORTED** | The point estimate is +0.03788 dex kpc^-1 with 95% CI [-0.00207,+0.07783], which crosses zero. |
| A robust young-to-old sign reversal exists in raw $J_z$. | **NOT SUPPORTED** | Raw point estimates are non-negative, but the young slope is unresolved; no transition is claimed. |
| $J_R$ has positive radial slopes across the OC age strata. | **SUPPORTED** | Young/intermediate/old slopes are +0.04546, +0.04227, and +0.04048 dex kpc^-1, with stored intervals excluding zero. |
| Stellar raw $J_z$ declines with $R_g$. | **SUPPORTED** | The 245116-star benchmark has beta_R=-0.02586 dex kpc^-1 (95% CI [-0.02730,-0.02442]); all four fixed $J_R$ quartiles are negative. |
| Stellar $J_z$ radial slope is monotonically ordered by $J_R$. | **NOT SUPPORTED** | Q1--Q4 are -0.05144, -0.02355, -0.01507, and -0.02852 dex kpc^-1; the sequence is non-monotonic. |
| Stellar $J_R$ ordering reproduces OC chronological ordering. | **NOT SUPPORTED** | Continuous beta_R,JR=+0.00016 is unresolved and the quartile sequence is not monotonic. |
| $J_z/|L_z|$ normalization materially changes radial behaviour. | **SUPPORTED** | OC and stellar radial coefficients change materially; stellar values are raw -0.02586/+0.00016 versus normalized -0.07871/-0.02011. |
| Selection effects have been eliminated. | **NOT SUPPORTED** | The HUNT24 selection function is incomplete; only predefined sensitivity variants were tested. |
| Tested trends survive predefined selection sensitivity tests. | **SUPPORTED** | Distance, RV-member, membership, inner-disc, and nuisance-adjusted variants retain positive raw-$J_z$ age--radius direction. |
| Warp has been fully modeled. | **NOT SUPPORTED** | No exact warped-potential actions or published warp-midplane correction were available; W3 is unavailable. |
| Axisymmetric-action interpretation remains warp-sensitive. | **SUPPORTED** | The tested warp-sensitive restrictions retain broad direction but materially change amplitude in the most restrictive inner sample. |

## Additional guardrails

- The selected stellar benchmark is not generalized to all Galactic field stars.
- The four stellar quartile slopes are all negative, but no monotonic or systematic $J_R$ ordering is stated.
- The OC--star contrast is not assigned uniquely to birth conditions, survival, heating, migration, flaring, warp, or selection.
- Normalized actions are described as normalization-dependent sensitivity diagnostics; raw actions remain primary for physical interpretation.
